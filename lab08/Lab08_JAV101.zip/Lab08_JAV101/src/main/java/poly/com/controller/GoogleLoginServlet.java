package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/google-login")
public class GoogleLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String token = req.getParameter("credential");

        if (token == null) {
            resp.getWriter().println("Không nhận được token từ Google!");
            return;
        }

        System.out.println("Token Google nhận được: " + token);

        req.getSession().setAttribute("user", "google_user");

        resp.sendRedirect("menu.jsp");
    }
}

