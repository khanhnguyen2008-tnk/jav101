package poly.com.dao;

import poly.com.dao.DepartmentDao;

public class Maintestdao {
	public static void main(String[] args) {
	DepartmentDao Dedao = new DepartmentDao();
	Dedao.printAllDepartments();
	EmployeesDao Empdao = new EmployeesDao();
	Empdao.printAllEmployees();
	}
}
