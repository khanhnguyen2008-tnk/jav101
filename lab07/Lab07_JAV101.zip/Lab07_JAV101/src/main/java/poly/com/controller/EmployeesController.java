package poly.com.controller;

import poly.com.dao.EmployeesDao;
import poly.com.model.Employees;
import poly.com.model.Departments;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = {
        "/employees", "/employees/",
        "/employees/add", "/employees/add/",
        "/employees/delete", "/employees/delete/",
        "/employees/update", "/employees/update/",
        "/employees/edit", "/employees/edit/",
        "/employees/search", "/employees/search/"
})
@MultipartConfig
public class EmployeesController extends HttpServlet {

    private EmployeesDao employeesDao = new EmployeesDao();
    private final String UPLOAD_DIR = "uploads";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getServletPath();

        try {
            switch (action) {

                case "/employees":
                    showEmployees(request, response);
                    break;

                case "/employees/delete":
                    deleteEmployee(request, response);
                    break;

                case "/employees/edit":
                    editEmployee(request, response);
                    break;

                case "/employees/search":
                    searchEmployee(request, response);
                    break;

                default:
                    showEmployees(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Có lỗi xảy ra: " + e.getMessage());
            showEmployees(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        try {
            if ("add".equalsIgnoreCase(action)) {
                addEmployee(request, response);

            } else if ("update".equalsIgnoreCase(action)) {
                updateEmployee(request, response);

            } else if ("delete".equalsIgnoreCase(action)) {
                deleteEmployee(request, response);

            } else {
                showEmployees(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Có lỗi xảy ra: " + e.getMessage());
            showEmployees(request, response);
        }
    }

    private void showEmployees(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Employees> allEmployees = employeesDao.getAllEmployees();
        List<Departments> deptList = employeesDao.getAllDepartments(); 

        request.setAttribute("employees", allEmployees);
        request.setAttribute("departments", deptList); 

        request.getRequestDispatcher("/employees.jsp").forward(request, response);
    }

    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        if (id != null && !id.trim().isEmpty()) {
            employeesDao.deleteEmployee(id);
            request.setAttribute("message", "Xóa nhân viên thành công!");
        } else {
            request.setAttribute("message", "ID không hợp lệ để xóa nhân viên!");
        }

        showEmployees(request, response);
    }

    private void editEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        if (id != null && !id.trim().isEmpty()) {

            Employees emp = employeesDao.findEmployeeById(id);
            if (emp != null) {
                request.setAttribute("editEmployee", emp);
            } else {
                request.setAttribute("message", "Nhân viên không tìm thấy để chỉnh sửa!");
            }
        }

        showEmployees(request, response);
    }

    private void searchEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        List<Employees> result = new ArrayList<>();

        if (id != null && !id.trim().isEmpty()) {
            Employees emp = employeesDao.findEmployeeById(id);
            if (emp != null) result.add(emp);
        } else {
            result = employeesDao.getAllEmployees();
        }

        request.setAttribute("employees", result);
        request.setAttribute("departments", employeesDao.getAllDepartments());

        request.getRequestDispatcher("/employees.jsp").forward(request, response);
    }

    private void addEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String fullname = request.getParameter("fullname");
        String departmentId = request.getParameter("departmentId");
        boolean gender = request.getParameter("gender") != null;
        Date birthday = parseDate(request.getParameter("birthday"));

        double salary = 0;
        try { salary = Double.parseDouble(request.getParameter("salary")); } catch (Exception e) {}

        String photo = uploadFile(request);

        employeesDao.insertEmployee(id, password, fullname, photo, gender, birthday, salary, departmentId);

        showEmployees(request, response);
    }

    private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String fullname = request.getParameter("fullname");
        String departmentId = request.getParameter("departmentId");
        boolean gender = request.getParameter("gender") != null;
        Date birthday = parseDate(request.getParameter("birthday"));

        double salary = 0;
        try { salary = Double.parseDouble(request.getParameter("salary")); } catch (Exception e) {}

        String photo = uploadFile(request);

        employeesDao.updateEmployee(id, password, fullname, photo, gender, birthday, salary, departmentId);

        showEmployees(request, response);
    }

    private String uploadFile(HttpServletRequest request)
            throws IOException, ServletException {

        Part filePart = request.getPart("photo");

        if (filePart == null || filePart.getSize() == 0)
            return "uploads/default.jpg";

        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

        File uploadsDir = new File(getServletContext().getRealPath("") + File.separator + UPLOAD_DIR);
        if (!uploadsDir.exists()) uploadsDir.mkdirs();

        String filePath = uploadsDir + File.separator + fileName;

        filePart.write(filePath);

        return UPLOAD_DIR + "/" + fileName;
    }

    private Date parseDate(String dateStr) {
        try {
            if (dateStr == null || dateStr.trim().isEmpty()) return null;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date utilDate = sdf.parse(dateStr);
            return new Date(utilDate.getTime());
        } catch (Exception e) {
            return null;
        }
    }
}