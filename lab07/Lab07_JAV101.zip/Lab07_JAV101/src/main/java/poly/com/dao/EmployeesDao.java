package poly.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.Statement;
import java.sql.Date; 
import java.util.ArrayList;
import java.util.List;

import poly.com.model.Departments;
import poly.com.model.Employees;

public class EmployeesDao extends Connectdao {

	public void insertEmployee(String id, String password, String fullname, String photo, Boolean gender, Date birthday, double salary, String departmentId) {
	    String sql = "INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	    
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setString(1, id);
	        ps.setString(2, password);
	        ps.setString(3, fullname);
	        ps.setString(4, photo);
	        ps.setBoolean(5, gender != null && gender); 
	        ps.setDate(6, birthday); 
	        ps.setDouble(7, salary);
	        ps.setString(8, departmentId);
	        ps.executeUpdate();
	        System.out.println("Thêm nhân viên thành công!");
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        
	    }
	}

	public void updateEmployee(String id, String password, String fullname, String photo, Boolean gender, Date updateBirthday, double salary, String departmentId) {
	    String sql = "UPDATE Employees SET Password = ?, Fullname = ?, Photo = ?, Gender = ?, Birthday = ?, Salary = ?, DepartmentId = ? WHERE Id = ?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setString(1, password);
	        ps.setString(2, fullname);
	        ps.setString(3, photo);
	        ps.setBoolean(4, gender != null && gender); 
	        ps.setDate(5, updateBirthday != null ? new java.sql.Date(updateBirthday.getTime()) : null); 
	        ps.setDouble(6, salary);
	        ps.setString(7, departmentId);
	        ps.setString(8, id);
	        int rowsUpdated = ps.executeUpdate();
	        if (rowsUpdated > 0) {
	            System.out.println("Cập nhật nhân viên thành công!");
	        } else {
	            System.out.println("Không tìm thấy nhân viên để cập nhật.");
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}

    public void deleteEmployee(String id) {
        String sql = "DELETE FROM Employees WHERE Id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
            System.out.println("Xóa nhân viên thành công!");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void addEmployee(String id, String password, String fullname, String photo, 
            Boolean gender, Date birthday, double salary, String departmentId) {
    	try {
    		CallableStatement stmt = conn.prepareCall("{call sp_AddEmployee(?, ?, ?, ?, ?, ?, ?, ?)}");

    		stmt.setString(1, id);
    		stmt.setString(2, password);
    		stmt.setString(3, fullname);
    		stmt.setString(4, photo);

    		if (gender == null) {
    			stmt.setNull(5, java.sql.Types.BIT);
    		} else {
    			stmt.setBoolean(5, gender);
    		}

    		stmt.setDate(6, birthday);
    		stmt.setDouble(7, salary);
    		stmt.setString(8, departmentId);

    		stmt.execute();
    		System.out.println("Thêm nhân viên thành công!");

    		} catch (Exception ex) {
    			ex.printStackTrace();
    		}
}
    
    public Employees findEmployeeById(String id) {
        String sql = "SELECT * FROM Employees WHERE Id = ?";
        Employees employee = null;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                employee = new Employees();
                employee.setId(rs.getString("Id"));
                employee.setPassword(rs.getString("Password"));
                employee.setFullname(rs.getString("Fullname"));
                employee.setPhoto(rs.getString("Photo"));
                employee.setGender(rs.getBoolean("Gender"));
                employee.setBirthday(rs.getDate("Birthday"));
                employee.setSalary(rs.getDouble("Salary"));
                employee.setDepartmentId(rs.getString("DepartmentId"));
            } else {
                System.out.println("Không tìm thấy nhân viên!");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return employee;
    }

    public List<Employees> getAllEmployees() {
		List<Employees> employees = new ArrayList<>();
		String sql = "SELECT * FROM Employees";
		try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Employees employee = new Employees();
				employee.setId(rs.getString("Id"));
				employee.setPassword(rs.getString("Password"));
				employee.setFullname(rs.getString("Fullname"));
				employee.setPhoto(rs.getString("Photo"));
				employee.setGender(rs.getBoolean("Gender"));
				employee.setBirthday(rs.getDate("Birthday")); 
				employee.setSalary(rs.getDouble("Salary"));
				employee.setDepartmentId(rs.getString("DepartmentId"));
				employees.add(employee); 
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return employees;
    }

    public void printAllEmployees() {
        List<Employees> employees = getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("Không có nhân viên nào!");
        } else {
            for (Employees employee : employees) {
                System.out.println("ID: " + employee.getId() + 
                                   ", Fullname: " + employee.getFullname() + 
                                   ", Department ID: " + employee.getDepartmentId());
            }
        }
    }
    public List<Departments> getAllDepartments() {
        List<Departments> list = new ArrayList<>();
        String sql = "SELECT id, name, description FROM Departments";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Departments d = new Departments();
                d.setId(rs.getString("id"));
                d.setName(rs.getString("name"));
                d.setDescription(rs.getString("description"));
                list.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
