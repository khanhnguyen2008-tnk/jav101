package poly.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Connectdao {
	
	protected static Connection conn;
		 
		public Connectdao()
	    {
		try {
	            String url = "jdbc:sqlserver://localhost:1433;databaseName=Lab06_JAV101";
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	            conn = DriverManager.getConnection(url, "sa", "123456");
	            System.out.println("Kết nối thành công!");
	        	} 
	        catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    }
}