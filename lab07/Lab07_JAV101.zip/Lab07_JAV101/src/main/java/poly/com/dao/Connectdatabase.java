package poly.com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Connectdatabase {
	 public static void main(String[] args) 
	    {
	 DepartmentDao dao = new DepartmentDao();
	   dao.printAllDepartments();
	    }
}
