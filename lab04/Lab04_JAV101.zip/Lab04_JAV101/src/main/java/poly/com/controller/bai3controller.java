package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai3")
public class bai3controller	extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String fullname = req.getParameter("fullname");
    String gender   = req.getParameter("gender");
    String country  = req.getParameter("country");
    String note     = req.getParameter("note");
    String[] hobby = req.getParameterValues("hobby");

    System.out.println("===== THÔNG TIN FORM =====");
    System.out.println("Họ tên: " + fullname);
    System.out.println("Giới tính: " + gender);
    System.out.println("Quốc tịch: " + country);

    if (hobby != null) {
        System.out.print("Sở thích: ");
        for (String h : hobby) {
            System.out.print(h + " ");
        }
        System.out.println();
    } else {
        System.out.println("Sở thích: (không chọn)");
    }

    System.out.println("Ghi chú: " + note);
    System.out.println("==========================");

    req.setAttribute("message", "Dữ liệu đã được in ra console!");
    req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
}
	}

