package poly.com.controller;

import java.io.IOException;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/bai2","/cal/add", "/cal/sub"})
public class bai2controller extends HttpServlet  {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	req.setAttribute("message", "Nhập số và chọn phép tính");
    req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 double a = Double.parseDouble(req.getParameter("a"));
	    double b = Double.parseDouble(req.getParameter("b"));

	    String path = req.getServletPath();

	    switch (path) {
	        case "/cal/add":
	            req.setAttribute("message", a + " + " + b + " = " + (a + b));
	            break;

	        case "/cal/sub":
	            req.setAttribute("message", a + " - " + b + " = " + (a - b));
	            break;

	        default:
	            req.setAttribute("message", "Sai đường dẫn xử lý!");
	            break;
	    }

	req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
	}
}
