package poly.com.controller;

import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import jakarta.servlet.http.Part;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai4")
@MultipartConfig

public class bai4controller extends HttpServlet{
	private static final long serialVersionUID = 1L;

	private static final String UPLOAD_DIRECTORY = "uploads";

@Override

protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	 req.getRequestDispatcher("/bai4.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	Part filePart = req.getPart("photo");
    String filename = filePart.getSubmittedFileName();
    
    String uploadPath = req.getServletContext().getRealPath("/") + "uploads";
    File uploadDir = new File(uploadPath); 
    
    if (!uploadDir.exists()) { uploadDir.mkdirs(); } 
    String filePath = uploadPath + File.separator + filename; 
    filePart.write(filePath); 
    
    req.setAttribute("photoURL", "uploads/" + filename);
    req.setAttribute("message", "Upload thành công!");
    req.getRequestDispatcher("/bai4.jsp").forward(req, resp);
 }
}
