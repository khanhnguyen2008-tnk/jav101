package poly.com.controller;

import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import jakarta.servlet.http.Part;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai4")
@MultipartConfig
public class bai4controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	 req.getRequestDispatcher("/bai4.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	Part photo = req.getPart("photo");
    String filename = photo.getSubmittedFileName();

    String uploadPath = req.getServletContext().getRealPath("/static/files");
    File folder = new File(uploadPath);
    if (!folder.exists()) {
        folder.mkdirs();
    }

    String newFilename = System.currentTimeMillis() + "_" + filename;
    File file = new File(uploadPath + "/" + newFilename);

    Files.copy(photo.getInputStream(), file.toPath());

    req.setAttribute("message", "Upload thành công! File lưu tại: static/files/" + newFilename);
    req.getRequestDispatcher("/bai4.jsp").forward(req, resp);
 }
	}
