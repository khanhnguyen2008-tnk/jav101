package poly.com.controller;

import java.io.IOException;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/bai3", "/nv/update", "/nv/create"})
public class bai3cotroller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	 Map<String, Object> map = new HashMap<>();
	 user bean = new user();
	 bean.setFullname("Nguyễn Văn Tèo");
	 bean.setGender(true);
	 bean.setCountry("VN");
	 req.setAttribute("user", bean);
     req.setAttribute("editable", true);

     req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String uri = req.getRequestURI();
    if (uri.contains("/nv/update")) {
        String fullname = req.getParameter("fullname");
        String gender = req.getParameter("gender");
        String country = req.getParameter("country");

        Map<String, Object> map = new HashMap<>();
        map.put("fullname", fullname);
        map.put("gender", gender);
        map.put("country", country);
        req.setAttribute("user", map);
        req.setAttribute("capnhat", "update success");
        req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
    } else if (uri.contains("/nv/create")) {
        String fullname = req.getParameter("fullname");
        String gender = req.getParameter("gender");
        String country = req.getParameter("country");
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", fullname);
        map.put("gender", gender);
        map.put("country", country);
        req.setAttribute("user", map);
        req.getRequestDispatcher("/form/themmoi.jsp").forward(req, resp);
      }
  }
}
