package poly.com.controller;

import java.io.IOException;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai3")
public class Bai3controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	 String url = req.getRequestURL().toString();
     String uri = req.getRequestURI();
     String queryString = req.getQueryString();
     String servletPath = req.getServletPath();
     String contextPath = req.getContextPath();
     String pathInfo = req.getPathInfo();
     String method = req.getMethod();

     resp.getWriter().println("<html><body>");
     resp.getWriter().println("<p><b>1. URL:</b> " + url + "</p>");
     resp.getWriter().println("<p><b>2. URI:</b> " + uri + "</p>");
     resp.getWriter().println("<p><b>3. QueryString:</b> " + queryString + "</p>");
     resp.getWriter().println("<p><b>4. ServletPath:</b> " + servletPath + "</p>");
     resp.getWriter().println("<p><b>5. ContextPath:</b> " + contextPath + "</p>");
     resp.getWriter().println("<p><b>6. PathInfo:</b> " + pathInfo + "</p>");
     resp.getWriter().println("<p><b>7. Method:</b> " + method + "</p>");
     resp.getWriter().println("</body></html>");
}
}
