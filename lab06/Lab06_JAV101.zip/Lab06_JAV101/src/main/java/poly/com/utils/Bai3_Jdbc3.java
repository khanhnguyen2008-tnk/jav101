package poly.com.utils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Bai3_Jdbc3 {

    protected static Connection conn;

    	 static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    	 static String dburl = "jdbc:sqlserver://localhost:1433;databaseName=Lab06_JAV101";
    	 static String username = "sa";
    	 static String password = "123456";
    	 static {
    		 try { 
    			 Class.forName(driver);
    			 } catch (ClassNotFoundException e) {
    			 throw new RuntimeException(e);
    			 }
    		 }
    
    			 public static Connection getConnection() throws SQLException {
    			 return DriverManager.getConnection(dburl, username, password);
    			 }
    			 
    			 public static int executeUpdate(String sql, Object... values) throws SQLException {
    			 Connection connection = getConnection();
    			 CallableStatement statement = connection.prepareCall(sql);
    			 for (int i = 0; i < values.length; i++) {
    			 statement.setObject(i + 1, values[i]);
    			 }
    			 return statement.executeUpdate();
    			 }
    			
    			 public static ResultSet executeQuery(String sql, Object... values) throws
    			 SQLException {
    			 Connection connection = getConnection();
    			 CallableStatement statement = connection.prepareCall(sql);
    			 for (int i = 0; i < values.length; i++) {

    			 statement.setObject(i + 1, values[i]);
    			 }
    			 return statement.executeQuery();
    			 }
    }

