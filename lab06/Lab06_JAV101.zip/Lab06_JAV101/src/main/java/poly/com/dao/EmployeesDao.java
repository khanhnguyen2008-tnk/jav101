package poly.com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import poly.com.model.Employees;
import poly.com.utils.Bai2_Jdbc2;

public class EmployeesDao {

    private Employees getEmployeeFromResultSet(ResultSet rs) throws SQLException {
        String id = rs.getString("Id");
        String password = rs.getString("Password");
        String fullname = rs.getString("Fullname");
        String photo = rs.getString("Photo");
        Boolean gender = rs.getBoolean("Gender");    
        Date birthday = rs.getDate("Birthday");
        double salary = rs.getDouble("Salary");      
        String departmentId = rs.getString("DepartmentId");

        return new Employees(id, password, fullname, photo, gender, birthday, salary, departmentId);
    }

    public List<Employees> getAllEmployees() {
        List<Employees> employees = new ArrayList<>();
        String sql = "SELECT * FROM Employees";

        try (
            Connection conn = Bai2_Jdbc2.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
        ) {
            while (rs.next()) {
                employees.add(getEmployeeFromResultSet(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return employees;
    }

    public void printAllEmployees() {
        String sql = "SELECT * FROM Employees";

        try (
            Connection conn = Bai2_Jdbc2.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
        ) {
            if (!rs.isBeforeFirst()) {
                System.out.println("Không có nhân viên nào!");
                return;
            }

            System.out.println("\n--- DANH SÁCH NHÂN VIÊN ---");
            while (rs.next()) {
                Employees emp = getEmployeeFromResultSet(rs);

                System.out.printf(
                    "ID: %s | Password: %s | Tên: %s | Ảnh: %s | Gender: %s | Ngày sinh: %s | Lương: %.0f | Phòng: %s%n",
                    emp.getId(),
                    emp.getPassword(),
                    emp.getFullname(),
                    emp.getPhoto(),
                    emp.getGender(),
                    emp.getBirthday(),
                    emp.getSalary(),
                    emp.getDepartmentId()
                );
            }
            System.out.println("----------------------------");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public void insertEmployees(String id, String password, String fullname, String photo,
            boolean gender, Date birthday, double salary, String departmentId) {

    	String sql = "INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) " +
    			"VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    	try (
			Connection conn = Bai2_Jdbc2.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			) {
		ps.setString(1, id);
		ps.setString(2, password);
		ps.setString(3, fullname);
		ps.setString(4, photo);
		ps.setBoolean(5, gender);             // primitive boolean
		ps.setDate(6, new java.sql.Date(birthday.getTime()));
		ps.setDouble(7, salary);
		ps.setString(8, departmentId);

		int rowsAffected = ps.executeUpdate();
		System.out.println(rowsAffected > 0 ? "Thêm nhân viên thành công: " + id
                            : "Thêm nhân viên thất bại!");
    	} catch (SQLException ex) {
    		ex.printStackTrace();
    	}
}

    public void updateEmployees(String id, String password, String fullname, String photo,
            Boolean gender, Date birthday, double salary, String departmentId) {

String sql = "UPDATE Employees SET Password = ?, Fullname = ?, Photo = ?, Gender = ?, " +
 "Birthday = ?, Salary = ?, DepartmentId = ? WHERE Id = ?";

	try (
			Connection conn = Bai2_Jdbc2.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			) {
		ps.setString(1, password);
		ps.setString(2, fullname);
		ps.setString(3, photo);
		ps.setBoolean(4, gender);
		ps.setDate(5, new java.sql.Date(birthday.getTime()));
		ps.setDouble(6, salary);
		ps.setString(7, departmentId);
		ps.setString(8, id);

		int rowsAffected = ps.executeUpdate();
		System.out.println(rowsAffected > 0 ? "Cập nhật nhân viên thành công: " + id
                            : "Không tìm thấy nhân viên để cập nhật!");
		} catch (SQLException ex) {	
		ex.printStackTrace();
			}
    }

    public void deleteEmployees(String id) {
        String sql = "DELETE FROM Employees WHERE Id = ?";

        try (
            Connection conn = Bai2_Jdbc2.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setString(1, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Xóa nhân viên thành công: " + id);
            } else {
                System.out.println("Xóa thất bại (Không tìm thấy ID)");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public Employees findEmployeeById(String id) {
        Employees employee = null;
        String sql = "SELECT * FROM Employees WHERE Id = ?";

        try (
            Connection conn = Bai2_Jdbc2.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setString(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    employee = getEmployeeFromResultSet(rs);
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return employee;
    }
}
