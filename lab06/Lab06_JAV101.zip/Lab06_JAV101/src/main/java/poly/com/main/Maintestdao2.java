package poly.com.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import poly.com.dao.EmployeesDao;

public class Maintestdao2 {
    public static void main(String[] args) {
        EmployeesDao Emdao = new EmployeesDao();
        Emdao.printAllEmployees();

        try {
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date birthday = sdf.parse("1989-02-01");

            
            //Emdao.insertEmployees("NV004", "123", "Nguyễn Văn D", "anhD.jpg", true, birthday, 9000000, "001");
            //Emdao.updateEmployees("NV004", "125", "Nguyễn Thị E", "anhE.jpg", false, birthday, 1000000, "002");
            //Emdao.deleteEmployees("NV004");

        } catch (ParseException e) {
            System.out.println("Lỗi định dạng ngày sinh!");
            e.printStackTrace();
        }
    }
}

