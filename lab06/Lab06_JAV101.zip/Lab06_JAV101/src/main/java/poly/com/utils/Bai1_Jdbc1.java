package poly.com.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Bai1_Jdbc1 {

    protected static Connection conn;

    	 static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    	 static String dburl = "jdbc:sqlserver://localhost:1433;databaseName=Lab06_JAV101";
    	 static String username = "sa";
    	 static String password = "123456";
    	 static {
    		 try {
    	            Class.forName(driver);
    	            System.out.println("Đăng nhập thành công");
    	        } catch (ClassNotFoundException e) {
    	            System.err.println("Đăng nhập thất bại");
    	            throw new RuntimeException(e);
    	        }
    		 
    		 }
    		 public static Connection getConnection() throws SQLException {
    		 return DriverManager.getConnection(dburl, username, password);
    		 }
    		 public static int executeUpdate(String sql) throws SQLException {
    		 Connection connection = getConnection();
    		 Statement statement = connection.createStatement();
    		 return statement.executeUpdate(sql);
    		 }
    		 
    		 public static ResultSet executeQuery(String sql) throws SQLException {
    		 Connection connection = getConnection();
    		 Statement statement = connection.createStatement();
    		 return statement.executeQuery(sql);
    		 }
    		 
    }

