package poly.com.main;

import poly.com.dao.DepartmentsDao3;

public class Maintestdao3 {
	public static void main(String[] args) {

		DepartmentsDao3 Dedao = new DepartmentsDao3();
        Dedao.printAllDepartments();
        //Dedao.insertDepartment("004", "Phòng MT", "Phòng Mỹ thuật");
        //Dedao.updateDepartment("004", "Phòng Kt", "Phòng Kỹ thuật");
        //Dedao.deleteDepartment("004");
    }
}
