package poly.com.dao;

import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;
import poly.com.model.Departments;
import poly.com.utils.Bai3_Jdbc3;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

	public class DepartmentsDao3 extends Bai3_Jdbc3 {
		public List<Departments> getAllDepartments() {
	        List<Departments> departments = new ArrayList<>(); 
	        String sql = "SELECT * FROM Departments";
	        
	        try (
	            Connection conn = Bai3_Jdbc3.getConnection(); 
	            Statement stmt = conn.createStatement();
	            ResultSet rs = stmt.executeQuery(sql);
	        ) {
	            while (rs.next()) {
	                String id = rs.getString("id");
	                String name = rs.getString("Name");
	                String description = rs.getString("Description");
	                departments.add(new Departments(id, name, description));
	            }
	        } catch (SQLException ex) { 
	            ex.printStackTrace();
	        }
	        return departments;
	    }
	    

	    public void insertDepartment(String id, String name, String description) {
	        String sql = "INSERT INTO Departments (id, Name, Description) VALUES (?, ?, ?)";
	        
	        try (
	            Connection conn = Bai3_Jdbc3.getConnection(); 
	            PreparedStatement ps = conn.prepareStatement(sql);
	        ) {
	            ps.setString(1, id);
	            ps.setString(2, name);
	            ps.setString(3, description);
	            int rowsAffected = ps.executeUpdate(); 
	            
	            if (rowsAffected > 0) {
	                 System.out.println("Thêm phòng ban thành công");
	            } else {
	                 System.out.println("Thêm phòng ban thất bại (Có thể do ID đã tồn tại)");
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    }
	    
	    public void updateDepartment(String id, String name, String description) {
	        String sql = "UPDATE Departments SET Name = ?, Description = ? WHERE id = ?";
	        
	        try (
	            Connection conn = Bai3_Jdbc3.getConnection(); 
	            PreparedStatement ps = conn.prepareStatement(sql);
	        ) {
	            ps.setString(1, name);
	            ps.setString(2, description);
	            ps.setString(3, id);
	            int rowsAffected = ps.executeUpdate();
	            
	            if (rowsAffected > 0) {
	                System.out.println("Cập nhật phòng ban thành công!");
	            } else {
	                System.out.println("Cập nhật thất bại (Không tìm thấy ID)");
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    }
	    
	    public void deleteDepartment(String id) {
	        String sql = "DELETE FROM Departments WHERE id = ?";
	        
	        try (
	            Connection conn = Bai3_Jdbc3.getConnection(); 
	            PreparedStatement ps = conn.prepareStatement(sql);
	        ) {
	            ps.setString(1, id);
	            int rowsAffected = ps.executeUpdate();
	            
	            if (rowsAffected > 0) {
	                System.out.println("Xóa phòng ban thành công");
	            } else {
	                 System.out.println("Xóa thất bại (Không tìm thấy ID)");
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    }
	    
	    public void printAllDepartments() {
	        String sql = "SELECT * FROM Departments";
	        
	        try (
	            Connection conn = Bai3_Jdbc3.getConnection(); 
	            Statement stmt = conn.createStatement();
	            ResultSet rs = stmt.executeQuery(sql);
	        ) {
	            if (!rs.isBeforeFirst()) {
	                System.out.println("Không có phòng ban nào!");
	                return;
	            }

	            System.out.println("\n--- DANH SÁCH PHÒNG BAN ---");
	            while (rs.next()) {
	                String id = rs.getString("id");
	                String name = rs.getString("Name");
	                String description = rs.getString("Description");
	                System.out.println("ID: " + id + ", Name: " + name + ", Description: " + description);
	            }
	            System.out.println("----------------------------");
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    }
	    
	    public Departments findDepartmentById1(String id) {
	        Departments department = null;
	        String sql = "SELECT * FROM Departments WHERE id = ?";
	        
	        try (
	            Connection conn = Bai3_Jdbc3.getConnection(); 
	            PreparedStatement ps = conn.prepareStatement(sql);
	        ) {
	            ps.setString(1, id);
	            
	            try (ResultSet rs = ps.executeQuery()) { 
	                if (rs.next()) {
	                    String name = rs.getString("Name");
	                    String description = rs.getString("Description");
	                    department = new Departments(id, name, description);
	                }
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	        return department;
	    }
	}
	
