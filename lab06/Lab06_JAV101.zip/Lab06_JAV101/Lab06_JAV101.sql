CREATE PROCEDURE spInsert(
@Id VARCHAR(20), 
@Name NVARCHAR(50), 
@Description NVARCHAR(100)
) AS BEGIN
INSERT INTO Departments(Id, Name, Description)
VALUES(@Id, @Name, @Description)
END

CREATE PROCEDURE spUpdate(
@Id VARCHAR(20), 
@Name NVARCHAR(50), 
@Description NVARCHAR(100)
) AS BEGIN
UPDATE Departments 
SET Name=@Name, Description=@Description 
WHERE Id=@Id
END

CREATE PROCEDURE spDeleteById(
@Id VARCHAR(20)
) AS BEGIN
DELETE FROM Departments WHERE Id=@Id
END

CREATE PROCEDURE spSelectAll() 
LAB 6: LẬP TRÌNH WEB CƠ BẢN
LẬP TRÌNH WEB CƠ BẢN TRANG 6
AS BEGIN
SELECT * FROM Departments
END

CREATE PROCEDURE spSelectById(
@Id VARCHAR(20)
) AS BEGIN
SELECT * FROM Departments WHERE Id=@Id
END