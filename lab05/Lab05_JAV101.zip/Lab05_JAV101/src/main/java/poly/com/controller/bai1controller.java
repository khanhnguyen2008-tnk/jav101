package poly.com.controller;
import java.io.IOException;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.Converter;
@WebServlet("/bai1")
public class bai1controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	req.getRequestDispatcher("/bai1.jsp").forward(req, resp);
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	staff bean = new staff();

    try {
    	DateConverter dateConverter = new DateConverter();
    	dateConverter.setPattern("MM/dd/yyyy");
    	ConvertUtils.register(dateConverter, java.util.Date.class);

        BeanUtils.populate(bean, req.getParameterMap());

        System.out.println("Fullname: " + bean.getFullname());
        System.out.println("Birthday: " + bean.getBirthday());
        System.out.println("Gender: " + bean.isGender());

        System.out.println("Hobbies:");
        if (bean.getHobbies() != null) {
            for (String h : bean.getHobbies()) {
                System.out.println(" - " + h);
            }
        }

        System.out.println("Country: " + bean.getCountry());
        System.out.println("Salary: " + bean.getSalary());

    } catch (Exception e) {
        e.printStackTrace();
    }

    req.setAttribute("bean", bean);
    req.getRequestDispatcher("/bai1.jsp").forward(req, resp);
 }
	}

