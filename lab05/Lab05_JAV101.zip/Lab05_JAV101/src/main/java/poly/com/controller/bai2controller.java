package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.utils.Mailer; 

@WebServlet("/bai2")
public class bai2controller extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String from = req.getParameter("from");
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        try {
            Mailer.send(from, to, subject, body);
            req.setAttribute("message", "Gửi email thành công!");
            req.setAttribute("messageType", "success");
        } catch (Exception e) {
            req.setAttribute("message", "Gửi email thất bại: " + e.getMessage());
            req.setAttribute("messageType", "danger");
        }

        req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
    }
}

