package poly.com.controller;

import java.io.IOException;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;
import java.util.Base64;

@WebServlet("/bai3")
public class bai3controller extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("user".equals(cookie.getName())) {
                    String encoded = cookie.getValue();
                    byte[] decodedBytes = Base64.getDecoder().decode(encoded);
                    String[] userInfo = new String(decodedBytes).split(",");
                    if (userInfo.length == 2) {
                        req.setAttribute("username", userInfo[0]);
                        req.setAttribute("password", userInfo[1]);
                    }
                }
            }
        }
    	req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	 String username = req.getParameter("username");
         String password = req.getParameter("password");
         String remember = req.getParameter("remember-me");

         if ("nguyentktv00180@gmail.com".equalsIgnoreCase(username) && "nguyen052008".equals(password)) {
             req.setAttribute("message", "Login successfully!");
             req.getSession().setAttribute("username", username); 

             if (remember != null) {
                 String userInfo = username + "," + password;
                 String encoded = Base64.getEncoder().encodeToString(userInfo.getBytes());

                 Cookie cookie = new Cookie("user", encoded);
                 cookie.setMaxAge(30 * 24 * 60 * 60); 
                 cookie.setPath("/");
                 resp.addCookie(cookie);
             }
         } else {
             req.setAttribute("message", "Invalid login info!");
         }

         req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
     }
    }


